<?php
$baseUrl = 'http://localhost/paypal-pdt-php/buy_now_button';
?>

<h2>Pedido cancelado</h2>
<p>El pedido fue cancelado, vuelve a la página de compra dando clic <a href="<?= $baseUrl ?>/formulario.php">aquí</a></p>